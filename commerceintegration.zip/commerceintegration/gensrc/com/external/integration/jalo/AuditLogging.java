/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN! ---
 * --- Generated at 21 Feb 2024, 16:26:10                       ---
 * ----------------------------------------------------------------
 */
package com.external.integration.jalo;

import de.hybris.platform.directpersistence.annotation.SLDSafe;
import de.hybris.platform.jalo.GenericItem;
import de.hybris.platform.jalo.Item.AttributeMode;
import de.hybris.platform.jalo.SessionContext;
import de.hybris.platform.jalo.enumeration.EnumerationValue;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * Generated class for type AuditLogging.
 */
@SLDSafe
@SuppressWarnings({"unused","cast"})
public class AuditLogging extends GenericItem
{
	/** Qualifier of the <code>AuditLogging.responseCode</code> attribute **/
	public static final String RESPONSECODE = "responseCode";
	/** Qualifier of the <code>AuditLogging.type</code> attribute **/
	public static final String TYPE = "type";
	/** Qualifier of the <code>AuditLogging.message</code> attribute **/
	public static final String MESSAGE = "message";
	/** Qualifier of the <code>AuditLogging.stackTrace</code> attribute **/
	public static final String STACKTRACE = "stackTrace";
	/** Qualifier of the <code>AuditLogging.userId</code> attribute **/
	public static final String USERID = "userId";
	/** Qualifier of the <code>AuditLogging.userPk</code> attribute **/
	public static final String USERPK = "userPk";
	/** Qualifier of the <code>AuditLogging.sessionId</code> attribute **/
	public static final String SESSIONID = "sessionId";
	/** Qualifier of the <code>AuditLogging.endPointUrl</code> attribute **/
	public static final String ENDPOINTURL = "endPointUrl";
	/** Qualifier of the <code>AuditLogging.requestLog</code> attribute **/
	public static final String REQUESTLOG = "requestLog";
	/** Qualifier of the <code>AuditLogging.responseLog</code> attribute **/
	public static final String RESPONSELOG = "responseLog";
	/** Qualifier of the <code>AuditLogging.requestName</code> attribute **/
	public static final String REQUESTNAME = "requestName";
	/** Qualifier of the <code>AuditLogging.attemptNumber</code> attribute **/
	public static final String ATTEMPTNUMBER = "attemptNumber";
	/** Qualifier of the <code>AuditLogging.processActionType</code> attribute **/
	public static final String PROCESSACTIONTYPE = "processActionType";
	/** Qualifier of the <code>AuditLogging.processStep</code> attribute **/
	public static final String PROCESSSTEP = "processStep";
	/** Qualifier of the <code>AuditLogging.requestTime</code> attribute **/
	public static final String REQUESTTIME = "requestTime";
	protected static final Map<String, AttributeMode> DEFAULT_INITIAL_ATTRIBUTES;
	static
	{
		final Map<String, AttributeMode> tmp = new HashMap<String, AttributeMode>();
		tmp.put(RESPONSECODE, AttributeMode.INITIAL);
		tmp.put(TYPE, AttributeMode.INITIAL);
		tmp.put(MESSAGE, AttributeMode.INITIAL);
		tmp.put(STACKTRACE, AttributeMode.INITIAL);
		tmp.put(USERID, AttributeMode.INITIAL);
		tmp.put(USERPK, AttributeMode.INITIAL);
		tmp.put(SESSIONID, AttributeMode.INITIAL);
		tmp.put(ENDPOINTURL, AttributeMode.INITIAL);
		tmp.put(REQUESTLOG, AttributeMode.INITIAL);
		tmp.put(RESPONSELOG, AttributeMode.INITIAL);
		tmp.put(REQUESTNAME, AttributeMode.INITIAL);
		tmp.put(ATTEMPTNUMBER, AttributeMode.INITIAL);
		tmp.put(PROCESSACTIONTYPE, AttributeMode.INITIAL);
		tmp.put(PROCESSSTEP, AttributeMode.INITIAL);
		tmp.put(REQUESTTIME, AttributeMode.INITIAL);
		DEFAULT_INITIAL_ATTRIBUTES = Collections.unmodifiableMap(tmp);
	}
	@Override
	protected Map<String, AttributeMode> getDefaultAttributeModes()
	{
		return DEFAULT_INITIAL_ATTRIBUTES;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>AuditLogging.attemptNumber</code> attribute.
	 * @return the attemptNumber - This gives the actual number of the attempt made to the request
	 */
	public Integer getAttemptNumber(final SessionContext ctx)
	{
		return (Integer)getProperty( ctx, "attemptNumber".intern());
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>AuditLogging.attemptNumber</code> attribute.
	 * @return the attemptNumber - This gives the actual number of the attempt made to the request
	 */
	public Integer getAttemptNumber()
	{
		return getAttemptNumber( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>AuditLogging.attemptNumber</code> attribute. 
	 * @return the attemptNumber - This gives the actual number of the attempt made to the request
	 */
	public int getAttemptNumberAsPrimitive(final SessionContext ctx)
	{
		Integer value = getAttemptNumber( ctx );
		return value != null ? value.intValue() : 0;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>AuditLogging.attemptNumber</code> attribute. 
	 * @return the attemptNumber - This gives the actual number of the attempt made to the request
	 */
	public int getAttemptNumberAsPrimitive()
	{
		return getAttemptNumberAsPrimitive( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>AuditLogging.attemptNumber</code> attribute. 
	 * @param value the attemptNumber - This gives the actual number of the attempt made to the request
	 */
	public void setAttemptNumber(final SessionContext ctx, final Integer value)
	{
		setProperty(ctx, "attemptNumber".intern(),value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>AuditLogging.attemptNumber</code> attribute. 
	 * @param value the attemptNumber - This gives the actual number of the attempt made to the request
	 */
	public void setAttemptNumber(final Integer value)
	{
		setAttemptNumber( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>AuditLogging.attemptNumber</code> attribute. 
	 * @param value the attemptNumber - This gives the actual number of the attempt made to the request
	 */
	public void setAttemptNumber(final SessionContext ctx, final int value)
	{
		setAttemptNumber( ctx,Integer.valueOf( value ) );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>AuditLogging.attemptNumber</code> attribute. 
	 * @param value the attemptNumber - This gives the actual number of the attempt made to the request
	 */
	public void setAttemptNumber(final int value)
	{
		setAttemptNumber( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>AuditLogging.endPointUrl</code> attribute.
	 * @return the endPointUrl
	 */
	public String getEndPointUrl(final SessionContext ctx)
	{
		return (String)getProperty( ctx, "endPointUrl".intern());
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>AuditLogging.endPointUrl</code> attribute.
	 * @return the endPointUrl
	 */
	public String getEndPointUrl()
	{
		return getEndPointUrl( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>AuditLogging.endPointUrl</code> attribute. 
	 * @param value the endPointUrl
	 */
	public void setEndPointUrl(final SessionContext ctx, final String value)
	{
		setProperty(ctx, "endPointUrl".intern(),value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>AuditLogging.endPointUrl</code> attribute. 
	 * @param value the endPointUrl
	 */
	public void setEndPointUrl(final String value)
	{
		setEndPointUrl( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>AuditLogging.message</code> attribute.
	 * @return the message - message/exception occurred
	 */
	public String getMessage(final SessionContext ctx)
	{
		return (String)getProperty( ctx, "message".intern());
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>AuditLogging.message</code> attribute.
	 * @return the message - message/exception occurred
	 */
	public String getMessage()
	{
		return getMessage( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>AuditLogging.message</code> attribute. 
	 * @param value the message - message/exception occurred
	 */
	public void setMessage(final SessionContext ctx, final String value)
	{
		setProperty(ctx, "message".intern(),value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>AuditLogging.message</code> attribute. 
	 * @param value the message - message/exception occurred
	 */
	public void setMessage(final String value)
	{
		setMessage( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>AuditLogging.processActionType</code> attribute.
	 * @return the processActionType - Action in bussiness process which caused consignment creation failure
	 */
	public String getProcessActionType(final SessionContext ctx)
	{
		return (String)getProperty( ctx, "processActionType".intern());
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>AuditLogging.processActionType</code> attribute.
	 * @return the processActionType - Action in bussiness process which caused consignment creation failure
	 */
	public String getProcessActionType()
	{
		return getProcessActionType( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>AuditLogging.processActionType</code> attribute. 
	 * @param value the processActionType - Action in bussiness process which caused consignment creation failure
	 */
	public void setProcessActionType(final SessionContext ctx, final String value)
	{
		setProperty(ctx, "processActionType".intern(),value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>AuditLogging.processActionType</code> attribute. 
	 * @param value the processActionType - Action in bussiness process which caused consignment creation failure
	 */
	public void setProcessActionType(final String value)
	{
		setProcessActionType( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>AuditLogging.processStep</code> attribute.
	 * @return the processStep - The Step which caused consignment creation failure
	 */
	public String getProcessStep(final SessionContext ctx)
	{
		return (String)getProperty( ctx, "processStep".intern());
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>AuditLogging.processStep</code> attribute.
	 * @return the processStep - The Step which caused consignment creation failure
	 */
	public String getProcessStep()
	{
		return getProcessStep( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>AuditLogging.processStep</code> attribute. 
	 * @param value the processStep - The Step which caused consignment creation failure
	 */
	public void setProcessStep(final SessionContext ctx, final String value)
	{
		setProperty(ctx, "processStep".intern(),value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>AuditLogging.processStep</code> attribute. 
	 * @param value the processStep - The Step which caused consignment creation failure
	 */
	public void setProcessStep(final String value)
	{
		setProcessStep( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>AuditLogging.requestLog</code> attribute.
	 * @return the requestLog
	 */
	public String getRequestLog(final SessionContext ctx)
	{
		return (String)getProperty( ctx, "requestLog".intern());
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>AuditLogging.requestLog</code> attribute.
	 * @return the requestLog
	 */
	public String getRequestLog()
	{
		return getRequestLog( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>AuditLogging.requestLog</code> attribute. 
	 * @param value the requestLog
	 */
	public void setRequestLog(final SessionContext ctx, final String value)
	{
		setProperty(ctx, "requestLog".intern(),value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>AuditLogging.requestLog</code> attribute. 
	 * @param value the requestLog
	 */
	public void setRequestLog(final String value)
	{
		setRequestLog( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>AuditLogging.requestName</code> attribute.
	 * @return the requestName
	 */
	public String getRequestName(final SessionContext ctx)
	{
		return (String)getProperty( ctx, "requestName".intern());
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>AuditLogging.requestName</code> attribute.
	 * @return the requestName
	 */
	public String getRequestName()
	{
		return getRequestName( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>AuditLogging.requestName</code> attribute. 
	 * @param value the requestName
	 */
	public void setRequestName(final SessionContext ctx, final String value)
	{
		setProperty(ctx, "requestName".intern(),value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>AuditLogging.requestName</code> attribute. 
	 * @param value the requestName
	 */
	public void setRequestName(final String value)
	{
		setRequestName( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>AuditLogging.requestTime</code> attribute.
	 * @return the requestTime - This is the exact time where the request was called
	 */
	public Date getRequestTime(final SessionContext ctx)
	{
		return (Date)getProperty( ctx, "requestTime".intern());
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>AuditLogging.requestTime</code> attribute.
	 * @return the requestTime - This is the exact time where the request was called
	 */
	public Date getRequestTime()
	{
		return getRequestTime( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>AuditLogging.requestTime</code> attribute. 
	 * @param value the requestTime - This is the exact time where the request was called
	 */
	public void setRequestTime(final SessionContext ctx, final Date value)
	{
		setProperty(ctx, "requestTime".intern(),value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>AuditLogging.requestTime</code> attribute. 
	 * @param value the requestTime - This is the exact time where the request was called
	 */
	public void setRequestTime(final Date value)
	{
		setRequestTime( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>AuditLogging.responseCode</code> attribute.
	 * @return the responseCode - Response Code Received From the Service
	 */
	public String getResponseCode(final SessionContext ctx)
	{
		return (String)getProperty( ctx, "responseCode".intern());
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>AuditLogging.responseCode</code> attribute.
	 * @return the responseCode - Response Code Received From the Service
	 */
	public String getResponseCode()
	{
		return getResponseCode( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>AuditLogging.responseCode</code> attribute. 
	 * @param value the responseCode - Response Code Received From the Service
	 */
	public void setResponseCode(final SessionContext ctx, final String value)
	{
		setProperty(ctx, "responseCode".intern(),value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>AuditLogging.responseCode</code> attribute. 
	 * @param value the responseCode - Response Code Received From the Service
	 */
	public void setResponseCode(final String value)
	{
		setResponseCode( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>AuditLogging.responseLog</code> attribute.
	 * @return the responseLog
	 */
	public String getResponseLog(final SessionContext ctx)
	{
		return (String)getProperty( ctx, "responseLog".intern());
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>AuditLogging.responseLog</code> attribute.
	 * @return the responseLog
	 */
	public String getResponseLog()
	{
		return getResponseLog( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>AuditLogging.responseLog</code> attribute. 
	 * @param value the responseLog
	 */
	public void setResponseLog(final SessionContext ctx, final String value)
	{
		setProperty(ctx, "responseLog".intern(),value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>AuditLogging.responseLog</code> attribute. 
	 * @param value the responseLog
	 */
	public void setResponseLog(final String value)
	{
		setResponseLog( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>AuditLogging.sessionId</code> attribute.
	 * @return the sessionId - user's session id
	 */
	public String getSessionId(final SessionContext ctx)
	{
		return (String)getProperty( ctx, "sessionId".intern());
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>AuditLogging.sessionId</code> attribute.
	 * @return the sessionId - user's session id
	 */
	public String getSessionId()
	{
		return getSessionId( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>AuditLogging.sessionId</code> attribute. 
	 * @param value the sessionId - user's session id
	 */
	public void setSessionId(final SessionContext ctx, final String value)
	{
		setProperty(ctx, "sessionId".intern(),value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>AuditLogging.sessionId</code> attribute. 
	 * @param value the sessionId - user's session id
	 */
	public void setSessionId(final String value)
	{
		setSessionId( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>AuditLogging.stackTrace</code> attribute.
	 * @return the stackTrace - Full exception stacktrace
	 */
	public String getStackTrace(final SessionContext ctx)
	{
		return (String)getProperty( ctx, "stackTrace".intern());
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>AuditLogging.stackTrace</code> attribute.
	 * @return the stackTrace - Full exception stacktrace
	 */
	public String getStackTrace()
	{
		return getStackTrace( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>AuditLogging.stackTrace</code> attribute. 
	 * @param value the stackTrace - Full exception stacktrace
	 */
	public void setStackTrace(final SessionContext ctx, final String value)
	{
		setProperty(ctx, "stackTrace".intern(),value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>AuditLogging.stackTrace</code> attribute. 
	 * @param value the stackTrace - Full exception stacktrace
	 */
	public void setStackTrace(final String value)
	{
		setStackTrace( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>AuditLogging.type</code> attribute.
	 * @return the type - Type of audit logging
	 */
	public EnumerationValue getType(final SessionContext ctx)
	{
		return (EnumerationValue)getProperty( ctx, "type".intern());
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>AuditLogging.type</code> attribute.
	 * @return the type - Type of audit logging
	 */
	public EnumerationValue getType()
	{
		return getType( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>AuditLogging.type</code> attribute. 
	 * @param value the type - Type of audit logging
	 */
	public void setType(final SessionContext ctx, final EnumerationValue value)
	{
		setProperty(ctx, "type".intern(),value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>AuditLogging.type</code> attribute. 
	 * @param value the type - Type of audit logging
	 */
	public void setType(final EnumerationValue value)
	{
		setType( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>AuditLogging.userId</code> attribute.
	 * @return the userId - session user's id
	 */
	public String getUserId(final SessionContext ctx)
	{
		return (String)getProperty( ctx, "userId".intern());
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>AuditLogging.userId</code> attribute.
	 * @return the userId - session user's id
	 */
	public String getUserId()
	{
		return getUserId( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>AuditLogging.userId</code> attribute. 
	 * @param value the userId - session user's id
	 */
	public void setUserId(final SessionContext ctx, final String value)
	{
		setProperty(ctx, "userId".intern(),value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>AuditLogging.userId</code> attribute. 
	 * @param value the userId - session user's id
	 */
	public void setUserId(final String value)
	{
		setUserId( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>AuditLogging.userPk</code> attribute.
	 * @return the userPk - session user's PK
	 */
	public String getUserPk(final SessionContext ctx)
	{
		return (String)getProperty( ctx, "userPk".intern());
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>AuditLogging.userPk</code> attribute.
	 * @return the userPk - session user's PK
	 */
	public String getUserPk()
	{
		return getUserPk( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>AuditLogging.userPk</code> attribute. 
	 * @param value the userPk - session user's PK
	 */
	public void setUserPk(final SessionContext ctx, final String value)
	{
		setProperty(ctx, "userPk".intern(),value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>AuditLogging.userPk</code> attribute. 
	 * @param value the userPk - session user's PK
	 */
	public void setUserPk(final String value)
	{
		setUserPk( getSession().getSessionContext(), value );
	}
	
}
