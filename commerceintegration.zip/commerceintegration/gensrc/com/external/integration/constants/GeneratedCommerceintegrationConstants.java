/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN! ---
 * --- Generated at 21 Feb 2024, 16:26:10                       ---
 * ----------------------------------------------------------------
 */
package com.external.integration.constants;

/**
 * @deprecated since ages - use constants in Model classes instead
 */
@Deprecated(since = "ages", forRemoval = false)
@SuppressWarnings({"unused","cast"})
public class GeneratedCommerceintegrationConstants
{
	public static final String EXTENSIONNAME = "commerceintegration";
	public static class TC
	{
		public static final String AUDITLOGGING = "AuditLogging".intern();
		public static final String AUDITLOGGINGTYPEENUM = "AuditLoggingTypeEnum".intern();
	}
	public static class Attributes
	{
		// no constants defined.
	}
	public static class Enumerations
	{
		public static class AuditLoggingTypeEnum
		{
			public static final String DEFAULT = "DEFAULT".intern();
		}
	}
	
	protected GeneratedCommerceintegrationConstants()
	{
		// private constructor
	}
	
	
}
