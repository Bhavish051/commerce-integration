package com.external.integration.error.handler;

import com.external.integration.exception.CommerceHttpClientErrorException;
import com.external.integration.exception.CommerceHttpServerErrorException;
import com.external.integration.exception.CommerceRestClientException;
import de.hybris.platform.util.Config;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.http.HttpStatus;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.web.client.DefaultResponseErrorHandler;
import org.springframework.web.client.RestClientException;

import java.io.IOException;
import java.util.Arrays;
import java.util.stream.IntStream;

/**
 * @author Abdul Rahman Sheikh M
 *
 */
public class DefaultCommerceRestResponseErrorHandler extends DefaultResponseErrorHandler
{

    private Boolean retry;
    private String serviceName;
    private String requestName;
    private static final String DOT = ".";

    public DefaultCommerceRestResponseErrorHandler(Boolean retry, String serviceName, String requestName)
    {
        this.retry = retry;
        this.serviceName = serviceName;
        this.requestName = requestName;
    }

    @Override
    public boolean hasError(ClientHttpResponse response) throws IOException
    {
        return this.hasError(this.getHttpStatusCode(response));
    }

    @Override
    public void handleError(ClientHttpResponse response) throws IOException
    {
        HttpStatus statusCode = this.getHttpStatusCode(response);
        byte[] responseBody = this.getResponseBody(response);
        String errorMessage = new String(responseBody);

        if(retry && isRetryNeededForServiceRequest(serviceName,requestName, statusCode.series().value()))
        {
            throw new CommerceRestClientException(serviceName, requestName, statusCode.toString(), errorMessage, statusCode, response.getStatusText(), response.getHeaders(), responseBody, this.getCharset(response));
        }
        else
        {
            switch(statusCode.series())
            {
                case CLIENT_ERROR:
                    throw new CommerceHttpClientErrorException(statusCode, response.getStatusText(), response.getHeaders(), this.getResponseBody(response), this.getCharset(response), errorMessage);
                case SERVER_ERROR:
                    throw new CommerceHttpServerErrorException(statusCode, response.getStatusText(), response.getHeaders(), this.getResponseBody(response), this.getCharset(response), errorMessage);
                default:
                    throw new RestClientException("Unknown status code [" + statusCode + "]. Error response: "+errorMessage);
            }
        }
    }

    private boolean isRetryNeededForServiceRequest(String serviceName, String requestName, int series)
    {
        boolean retryNeeded = false;
        String retryCodes = Config.getString(serviceName.toLowerCase()+DOT+requestName.toLowerCase()+DOT+"retry.errorcode.series", StringUtils.EMPTY);
        if(StringUtils.isNotEmpty(retryCodes))
        {
            int[] retryCodeSeries = Arrays.stream(retryCodes.split(","))
                                          .mapToInt(Integer::parseInt)
                                          .toArray();
            if(ArrayUtils.isNotEmpty(retryCodeSeries))
            {
                retryNeeded = IntStream.of(retryCodeSeries).anyMatch(n -> n == series);
            }
        }
        return retryNeeded;
    }

    public Boolean getRetry() {
        return retry;
    }

    public void setRetry(Boolean retry) {
        this.retry = retry;
    }

    public String getServiceName() {
        return serviceName;
    }

    public void setServiceName(String serviceName) {
        this.serviceName = serviceName;
    }

    public String getRequestName() {
        return requestName;
    }

    public void setRequestName(String requestName) {
        this.requestName = requestName;
    }

}
