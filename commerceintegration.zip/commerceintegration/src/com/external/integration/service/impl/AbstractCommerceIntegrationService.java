package com.external.integration.service.impl;

import com.external.integration.constants.CommerceintegrationConstants;
import com.external.integration.restclient.CommerceRestClient;
import de.hybris.platform.servicelayer.config.ConfigurationService;
import de.hybris.platform.servicelayer.i18n.CommonI18NService;
import de.hybris.platform.servicelayer.model.ModelService;
import de.hybris.platform.store.BaseStoreModel;
import de.hybris.platform.store.services.BaseStoreService;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.util.MultiValueMap;

import static com.external.integration.constants.CommerceintegrationConstants.*;

public abstract class AbstractCommerceIntegrationService<REQUEST, RESPONSE>
{

    private CommerceRestClient<REQUEST, RESPONSE> commerceRestClient;

    private ConfigurationService configurationService;

    private BaseStoreService baseStoreService;

    private CommonI18NService commonI18NService;
    private ModelService modelService;

    protected RESPONSE execute(String serviceName, String requestName, HttpHeaders httpHeaders, HttpMethod httpMethod, REQUEST request, RESPONSE response, boolean extractHeader, String headerName)
    {
        return getCommerceRestClient().execute(getDestinationEndpoint(serviceName, requestName),
                httpMethod, request, (Class<RESPONSE>) response, httpHeaders, serviceName, requestName,
                getMaxAttempt(serviceName, requestName), getRetryInterval(serviceName, requestName), extractHeader, headerName);
    }

    protected RESPONSE execute(String serviceName, String requestName, String url, HttpHeaders httpHeaders, HttpMethod httpMethod, REQUEST request, RESPONSE response, boolean extractHeader, String headerName)
    {
        return getCommerceRestClient().execute(url,
                httpMethod, request, (Class<RESPONSE>) response, httpHeaders, serviceName, requestName,
                getMaxAttempt(serviceName, requestName), getRetryInterval(serviceName, requestName), extractHeader, headerName);
    }

    protected ResponseEntity<String> getAccessToken(String serviceName, String requestName, HttpHeaders httpHeaders, MultiValueMap<String, String> bodyParamMap) {
        return getCommerceRestClient().getAccessToken(serviceName, requestName, getDestinationEndpoint(serviceName, requestName), httpHeaders, bodyParamMap);
    }
    protected ResponseEntity<String> execute(String serviceName, String requestName, HttpHeaders httpHeaders,final REQUEST requestData) {
        return getCommerceRestClient().execute(serviceName, requestName, getDestinationEndpoint(serviceName, requestName), httpHeaders, requestData);
    }
    protected abstract HttpHeaders populateHttpHeaders(String serviceName, String requestName);

    protected abstract HttpMethod populateHttpMethod();

       private String getDestinationEndpoint(String serviceName, String requestName){
        return getConfigurationService().getConfiguration().getString(serviceName + CommerceintegrationConstants.DOT + requestName + CommerceintegrationConstants.DOT + ENDPOINT);
    }

    private Integer getMaxAttempt(String serviceName, String requestName){
        return getConfigurationService().getConfiguration().getInteger(serviceName + CommerceintegrationConstants.DOT + requestName + CommerceintegrationConstants.DOT + MAX_ATTEMPT, 1);
    }
    private Integer getRetryInterval(String serviceName, String requestName){
        return getConfigurationService().getConfiguration().getInteger(serviceName + CommerceintegrationConstants.DOT +requestName + CommerceintegrationConstants.DOT + RETRY_INTERVAL, 2);
    }

    public CommerceRestClient<REQUEST, RESPONSE> getCommerceRestClient() {
        return commerceRestClient;
    }

    public void setCommerceRestClient(CommerceRestClient<REQUEST, RESPONSE> commerceRestClient) {
        this.commerceRestClient = commerceRestClient;
    }

    public ConfigurationService getConfigurationService() {
        return configurationService;
    }

    public void setConfigurationService(ConfigurationService configurationService) {
        this.configurationService = configurationService;
    }

    public BaseStoreService getBaseStoreService() {
        return baseStoreService;
    }

    public void setBaseStoreService(BaseStoreService baseStoreService) {
        this.baseStoreService = baseStoreService;
    }

    protected BaseStoreModel getBaseStore()
    {
        return this.getBaseStoreService().getBaseStoreForUid("csr");
    }

    public CommonI18NService getCommonI18NService() {
        return commonI18NService;
    }

    public void setCommonI18NService(CommonI18NService commonI18NService) {
        this.commonI18NService = commonI18NService;
    }

    public ModelService getModelService() {
        return modelService;
    }

    public void setModelService(ModelService modelService) {
        this.modelService = modelService;
    }
}