package com.external.integration.exception;

import de.hybris.platform.order.exceptions.CalculationException;

/**
 * @author Abdul Rahman Sheikh M
 *
 */
public class InvalidDataException extends CalculationException
{
    public InvalidDataException(String message)
    {
        super(message);
    }

}
