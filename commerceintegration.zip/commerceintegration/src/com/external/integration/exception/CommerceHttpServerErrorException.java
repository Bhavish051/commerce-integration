package com.external.integration.exception;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.web.client.HttpServerErrorException;

import java.nio.charset.Charset;

/**
 * @author Abdul Rahman Sheikh M
 */
public class CommerceHttpServerErrorException extends HttpServerErrorException
{
    String message;

    public CommerceHttpServerErrorException(HttpStatus statusCode, String message) {
        super(statusCode);
        this.message = message;
    }

    public CommerceHttpServerErrorException(HttpStatus statusCode, String statusText, String message) {
        super(statusCode, statusText);
        this.message = message;
    }

    public CommerceHttpServerErrorException(HttpStatus statusCode, String statusText, byte[] responseBody, Charset responseCharset, String message) {
        super(statusCode, statusText, responseBody, responseCharset);
        this.message = message;
    }

    public CommerceHttpServerErrorException(HttpStatus statusCode, String statusText, HttpHeaders responseHeaders, byte[] responseBody, Charset responseCharset, String message) {
        super(statusCode, statusText, responseHeaders, responseBody, responseCharset);
        this.message = message;
    }

    @Override
    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
