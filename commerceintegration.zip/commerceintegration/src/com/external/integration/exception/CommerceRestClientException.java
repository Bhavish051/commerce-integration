package com.external.integration.exception;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.web.client.RestClientException;

import java.nio.charset.Charset;

/**
 * @author Abdul Rahman Sheikh M
 *
 */
public class CommerceRestClientException extends RestClientException
{
    String serviceName;
    String requestName;
    String errorCode;
    HttpStatus statusCode;
    String statusText;
    private HttpHeaders responseHeaders;
    byte[] responseBody;
    private Charset responseCharset;

    public CommerceRestClientException(String message)
    {
        super(message);
    }

    public CommerceRestClientException(String serviceName, String requestName, String errorCode, String message)
    {
        super(message);
        this.serviceName=serviceName;
        this.requestName=requestName;
        this.errorCode=errorCode;
    }

    public CommerceRestClientException(String serviceName, String requestName, String errorCode, String errorMessage, HttpStatus statusCode, String statusText, HttpHeaders responseHeaders, byte[] responseBody, Charset responseCharset)
    {
        super(errorMessage);
        this.serviceName=serviceName;
        this.requestName=requestName;
        this.errorCode=errorCode;
        this.statusCode=statusCode;
        this.statusText=statusText;
        this.responseHeaders=responseHeaders;
        this.responseBody=responseBody;
        this.responseCharset=responseCharset;
    }

    public String getServiceName() {
        return serviceName;
    }

    public void setServiceName(String serviceName) {
        this.serviceName = serviceName;
    }

    public String getRequestName() {
        return requestName;
    }

    public void setRequestName(String requestName) {
        this.requestName = requestName;
    }

    public String getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    public HttpStatus getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(HttpStatus statusCode) {
        this.statusCode = statusCode;
    }

    public String getStatusText() {
        return statusText;
    }

    public void setStatusText(String statusText) {
        this.statusText = statusText;
    }

    public HttpHeaders getResponseHeaders() {
        return responseHeaders;
    }

    public void setResponseHeaders(HttpHeaders responseHeaders) {
        this.responseHeaders = responseHeaders;
    }

    public byte[] getResponseBody() {
        return responseBody;
    }

    public void setResponseBody(byte[] responseBody) {
        this.responseBody = responseBody;
    }

    public Charset getResponseCharset() {
        return responseCharset;
    }

    public void setResponseCharset(Charset responseCharset) {
        this.responseCharset = responseCharset;
    }

}
