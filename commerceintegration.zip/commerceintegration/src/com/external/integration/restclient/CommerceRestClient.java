package com.external.integration.restclient;

import com.external.integration.constants.CommerceintegrationConstants;
import com.external.integration.enums.AuditLoggingTypeEnum;
import com.external.integration.error.handler.DefaultCommerceRestResponseErrorHandler;
import com.external.integration.exception.CommerceRestClientException;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.external.integration.tasks.AuditLoggingTask;
import de.hybris.platform.servicelayer.model.ModelService;
import de.hybris.platform.servicelayer.session.SessionService;
import de.hybris.platform.servicelayer.user.UserService;
import de.hybris.platform.util.Config;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.task.TaskExecutor;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.retry.RetryCallback;
import org.springframework.retry.backoff.FixedBackOffPolicy;
import org.springframework.retry.policy.SimpleRetryPolicy;
import org.springframework.retry.support.RetryTemplate;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.*;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 * @author Abdul Rahman Sheikh M
 *
 * Common Rest client class for the integration calls from Commerce to other 3rd party systems.
 *
 * @param <REQUEST> - request data
 * @param <RESPONSE> - response data
 */
public class CommerceRestClient<REQUEST, RESPONSE>
{
    private static final Logger LOG = LoggerFactory.getLogger(CommerceRestClient.class);
    private RestTemplate restTemplate;
    private SessionService sessionService;
    private ModelService modelService;
    private UserService userService;
    private TaskExecutor taskExecutor;

    public  ResponseEntity<String> getAccessToken(String serviceName, String requestName, String url, HttpHeaders httpHeaders,MultiValueMap<String, String> bodyParamMap){
        String serviceRequest = serviceName + CommerceintegrationConstants.DOT + requestName;
        String[] logEnabledServices = Config.getString("log.enabled.services", StringUtils.EMPTY).split(",");
        boolean isLogEnabled = Arrays.stream(logEnabledServices).anyMatch(service -> StringUtils.equalsIgnoreCase(service, serviceRequest));

        RestTemplate restTemplate = new RestTemplate();
        HttpEntity entity = new HttpEntity<>(bodyParamMap, httpHeaders);

        if (isLogEnabled) {
            LOG.debug("SERVICE URL FOR THE SERVICE REQUEST - " +serviceRequest + " | URL: " + url + " | Request : " + entity);
        }
        return restTemplate.postForEntity(url, entity, String.class);
    }

    public ResponseEntity<String> execute(String serviceName, String requestName, String url, HttpHeaders httpHeaders, final REQUEST requestData) {
        String serviceRequest = serviceName + CommerceintegrationConstants.DOT + requestName;

        String[] logEnabledServices = Config.getString("log.enabled.services", StringUtils.EMPTY).split(",");
        boolean isLogEnabled = Arrays.stream(logEnabledServices).anyMatch(service -> StringUtils.equalsIgnoreCase(service, serviceRequest));

        String[] dbLoggingEnabledServices = Config.getString("database.save.enabled.services", StringUtils.EMPTY).split(",");
        boolean isDBLoggingEnabled = Arrays.stream(dbLoggingEnabledServices).anyMatch(service -> StringUtils.equalsIgnoreCase(service, serviceRequest));

        RestTemplate restTemplate = new RestTemplate();
        ObjectMapper mapper = new ObjectMapper();
        mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
        String requestForAudit = StringUtils.EMPTY;
        String responseForAudit = StringUtils.EMPTY;
        String responseCode = StringUtils.EMPTY;

        try {
            Gson gson = new Gson();

            if (null != requestData) {
                requestForAudit = gson.toJson(requestData);
            }
            if (isLogEnabled) {
                LOG.debug("SERVICE URL FOR THE SERVICE REQUEST - " +serviceRequest + " | URL: " + url + " | Request : " + requestForAudit);
            }
            final String jsonNote = mapper.writeValueAsString(requestData);
            HttpEntity entity = new HttpEntity<>(jsonNote, httpHeaders);
            ResponseEntity<String> responseEntity = restTemplate.postForEntity(url, entity, String.class);
            if (null != responseEntity && null != responseEntity.getBody()) {
                responseForAudit = gson.toJson(responseEntity.getBody());
                responseCode = responseEntity.getStatusCode().toString();
            }

            if (isLogEnabled)
            {
                LOG.debug("Response Status Code : {}", responseCode);
                LOG.debug("Response : "+ responseForAudit);
            }
            if(isDBLoggingEnabled)
            {
                saveAudit(serviceName, url, requestForAudit, responseForAudit, requestName, 1, responseCode);
            }
            return responseEntity;
        } catch (Exception e) {
            logError((RestClientException) e, serviceName, requestName, url, requestForAudit, responseForAudit, 1, responseCode);
            saveAudit(serviceName, url, requestForAudit, responseForAudit, requestName, 1, responseCode);
            handleException((RestClientException) e, serviceRequest);
        }
        return null;
    }
    /**
     *  This method frames the necessary details to call the API in subsequent method
     *  It is invoked by services layer with request data already populated
     *  Below is configurable based on the service and request name pair and can be change on the fly
     *  1. Log enabled or not
     *  2. AuditLog enabled or not
     *  3. Audit Logging  Override enabled or not
     *  4. Retry Enabled or not
     *  5. Others configs - endpoint url, max attempts, headers etc
     * @param url
     * @param httpMethod
     * @param requestData
     * @param responseClass
     * @param httpHeaders
     * @param serviceName
     * @param requestName
     * @param maxAttempt
     * @param retryInterval
     * @return
     * @throws ResourceAccessException
     * @throws RestClientException
     */
    public RESPONSE execute(final String url, final HttpMethod httpMethod, final REQUEST requestData,
                            final Class<RESPONSE> responseClass, HttpHeaders httpHeaders, String serviceName, String requestName,
                            Integer maxAttempt, Integer retryInterval, boolean extractHeader, String headerName) throws ResourceAccessException, RestClientException
    {
        String serviceRequest = serviceName + CommerceintegrationConstants.DOT + requestName;

        String[] logEnabledServices = Config.getString("log.enabled.services", StringUtils.EMPTY).split(",");
        boolean isLogEnabled = Arrays.stream(logEnabledServices).anyMatch(service -> StringUtils.equalsIgnoreCase(service, serviceRequest));

        String[] dbLoggingEnabledServices = Config.getString("database.save.enabled.services", StringUtils.EMPTY).split(",");
        boolean isDBLoggingEnabled = Arrays.stream(dbLoggingEnabledServices).anyMatch(service -> StringUtils.equalsIgnoreCase(service, serviceRequest));

        String[] retryEnabledServices = Config.getString("retry.enabled.services", StringUtils.EMPTY).split(",");
        boolean isRetryEnabled = Arrays.stream(retryEnabledServices).anyMatch(service -> StringUtils.equalsIgnoreCase(service, serviceRequest));

        setResponseErrorHandler(isRetryEnabled, serviceName, requestName);

        if(isRetryEnabled)
        {
            if(null == maxAttempt || maxAttempt == 0)
            {
                maxAttempt = Config.getInt("webservice.default.max.attempt",1);
                LOG.warn("Defaulting the max attempt of the service request: "+serviceRequest+" to 1");
            }
            if(null == retryInterval || retryInterval < 2)
            {
                retryInterval = Config.getInt("webservice.default.retry.interval",2);
                LOG.warn("Defaulting the retry interval of the service request: "+serviceRequest+" to 2");
            }
            LOG.debug("Calling the service request: "+serviceRequest+" with retry. Max attempt: "+ maxAttempt+" | Retry interval: " +retryInterval+"ms");
            return getRetryTemplate(maxAttempt, retryInterval)
                    .execute(
                            (RetryCallback<RESPONSE, ResourceAccessException>) context -> {
                                int retryCount = context.getRetryCount()+1;
                                LOG.debug("Calling the service request: " + serviceRequest +" Attempt: "+retryCount);
                                return executeInternal(url, httpMethod, requestData,responseClass, httpHeaders, serviceName, requestName, serviceRequest, isLogEnabled, isDBLoggingEnabled, retryCount, extractHeader, headerName);
                            });
        }
        else
        {
            LOG.debug("No retry enabled for the service request: "+serviceRequest);
            return executeInternal(url, httpMethod, requestData,responseClass, httpHeaders, serviceName, requestName, serviceRequest, isLogEnabled, isDBLoggingEnabled, 1, extractHeader, headerName);
        }
    }

    /**
     * This method actually makes the HTTP Request based on input parameters
     * @param url
     * @param httpMethod
     * @param requestData
     * @param responseClass
     * @param httpHeaders
     * @param serviceName
     * @param requestName
     * @param serviceRequest
     * @param isLogEnabled
     * @param isDBLoggingEnabled
     * @param attempt
     * @return
     * @throws ResourceAccessException
     * @throws RestClientException
     */
    private RESPONSE executeInternal(final String url, final HttpMethod httpMethod, final REQUEST requestData,
                                     final Class<RESPONSE> responseClass, HttpHeaders httpHeaders, String serviceName,
                                     String requestName, String serviceRequest, boolean isLogEnabled, boolean isDBLoggingEnabled, int attempt, boolean extractHeader, String headerName) throws ResourceAccessException, RestClientException
    {
        RESPONSE response = null;

        //Gson for converting POJO into JSON
        Gson gson = new Gson();

        String requestForAudit = StringUtils.EMPTY;
        String responseForAudit = StringUtils.EMPTY;
        String responseCode = StringUtils.EMPTY;

        if (null != requestData) {
            requestForAudit = gson.toJson(requestData);
        }
        if (isLogEnabled) {
            LOG.debug("SERVICE URL FOR THE SERVICE REQUEST - " +serviceRequest + " | URL: " + url + " | Request : " + requestForAudit);
        }
        ResponseEntity<RESPONSE> responseEntity;

        if(Config.getBoolean(CommerceintegrationConstants.INTEGRATION_ENABLE_KEY, true) && Config.getBoolean(serviceRequest+CommerceintegrationConstants.DOT+"enable" , false)) {
            try {
                ((HttpComponentsClientHttpRequestFactory)restTemplate.getRequestFactory()).setConnectTimeout(Config.getInt("rest.connection.timeout", 5000));
                ((HttpComponentsClientHttpRequestFactory)restTemplate.getRequestFactory()).setReadTimeout(Config.getInt("rest.read.timeout", 5000));

                if(null == httpHeaders) {
                    if (httpMethod.equals(HttpMethod.POST)) {
                        response = restTemplate.postForObject(url, requestForAudit, responseClass);
                    } else if (httpMethod.equals(HttpMethod.GET)) {
                        response = restTemplate.getForObject(url, responseClass);
                    }
                } else {
                    if (null != requestData) {
                        HttpEntity<REQUEST> requestEntity = new HttpEntity(requestData, httpHeaders);
                        responseEntity = restTemplate.exchange(url, httpMethod, requestEntity, responseClass);
                        responseCode = responseEntity.getStatusCode().toString();
                    } else {
                        HttpEntity<String> requestEntity = new HttpEntity<>(CommerceintegrationConstants.HTTP_ENTITY_KEY, httpHeaders);
                        responseEntity = restTemplate.exchange(url, httpMethod, requestEntity, responseClass);
                        responseCode = responseEntity.getStatusCode().toString();
                    }

                    if(extractHeader) {
                        List<String> headers = (List) responseEntity.getHeaders().get(headerName);
                        if(null != headers){
                            response = (RESPONSE) headers.get(0).toString();
                        }
                    } else {
                        response = responseEntity.getBody();
                    }
                }
            } catch (ResourceAccessException resourceAccessException) {
                responseForAudit = resourceAccessException.getMessage();
                logError(resourceAccessException, serviceName, requestName, url, requestForAudit, responseForAudit, attempt, responseCode);
                saveAudit(serviceName, url, requestForAudit, responseForAudit, requestName, attempt, responseCode);
                handleException(resourceAccessException, serviceRequest);

            } catch(HttpClientErrorException | HttpServerErrorException httpException) {
                responseForAudit = httpException.getMessage();
                logError(httpException, serviceName, requestName, url, requestForAudit, responseForAudit, attempt, responseCode);
                saveAudit(serviceName, url, requestForAudit, responseForAudit, requestName, attempt, responseCode);
                handleException(httpException, serviceRequest);
            } catch (RestClientException restClientException) {
                responseForAudit = restClientException.getMessage();
                logError(restClientException, serviceName, requestName, url, requestForAudit, responseForAudit, attempt, responseCode);
                saveAudit(serviceName, url, requestForAudit, responseForAudit, requestName, attempt, responseCode);
                handleException(restClientException, serviceRequest);
            }
        } else {
            LOG.error("Integration is disabled. Service request: {} is not executed, Please check your configurations", serviceRequest);
            return response;
        }

        if(null != response)
        {
            responseForAudit = gson.toJson(response);
        }
        if (isLogEnabled)
        {
            LOG.debug("Response Status Code : {}", responseCode);
            LOG.debug("Response : "+responseForAudit);
        }
        if(isDBLoggingEnabled)
        {
            saveAudit(serviceName, url, requestForAudit, responseForAudit, requestName, attempt, responseCode);
        }

        return response;
    }

    /**
     * This method logs error based on serviceName and request Name
     *
     * @param ex
     * @param serviceName
     * @param requestName
     * @param url
     * @param requestForAudit
     * @param responseForAudit
     * @param responseCode
     */
    private void logError(RestClientException ex, String serviceName, String requestName, String url, String requestForAudit, String responseForAudit, int attempt, String responseCode)
    {
        String sb = "Service name : " + serviceName + "\n" +
                "Request name : " + requestName + "\n" +
                "Attempt no : " + attempt + "\n" +
                "Endpoint : " + url + "\n" +
                "Request : " + requestForAudit + "\n" +
                "Response : " + responseForAudit + "\n" +
                "Response Code : " + responseCode;
        LOG.error(sb, ex);
    }

    /**
     * This method is used to save the request and response parameters in DB
     *
     * @param serviceName  - Name of the service
     * @param endPointUrl  - End point url
     * @param request      - request JSON
     * @param response     - response JSON
     * @param responseCode
     */
    private void saveAudit(final String serviceName, final String endPointUrl, String request, final String response, String requestName, int attempt, String responseCode)
    {
        AuditLoggingTask task = new AuditLoggingTask(getSessionService().getCurrentSession(), requestName, endPointUrl, request, response, attempt, responseCode, getUserService().getCurrentUser(), AuditLoggingTypeEnum.valueOf(serviceName.toUpperCase()), getModelService());
        getTaskExecutor().execute(task);
    }

    protected void handleException(RestClientException restClientException, String serviceRequest)
    {
        String[] exceptionEnabledServices = Config.getString("exception.enabled.services", StringUtils.EMPTY).split(",");
        boolean isExceptionEnabled = Arrays.stream(exceptionEnabledServices).anyMatch(service -> StringUtils.equalsIgnoreCase(service, serviceRequest));
        if(isExceptionEnabled)
        {
            throw restClientException;
        }
    }

    private RetryTemplate getRetryTemplate(int maxAttempt, int retryTimeInterval)
    {
        final Map<Class<? extends Throwable>, Boolean> exceptionMap = new HashMap<Class<? extends Throwable>, Boolean>();
        exceptionMap.put(ResourceAccessException.class, Boolean.TRUE);
        exceptionMap.put(CommerceRestClientException.class, Boolean.TRUE);
        final SimpleRetryPolicy retryPolicy = new SimpleRetryPolicy(maxAttempt, exceptionMap);

        final FixedBackOffPolicy backOffPolicy = new FixedBackOffPolicy();
        backOffPolicy.setBackOffPeriod(retryTimeInterval);//Milli seconds

        final RetryTemplate template = new RetryTemplate();
        template.setRetryPolicy(retryPolicy);
        template.setBackOffPolicy(backOffPolicy);

        return template;
    }

    private void setResponseErrorHandler(boolean isRetryEnabled, String serviceName, String requestName)
    {
        restTemplate.setErrorHandler(new DefaultCommerceRestResponseErrorHandler(isRetryEnabled, serviceName, requestName));
    }

    /**
     * @return the modelService
     */
    public ModelService getModelService() {
        return modelService;
    }

    /**
     * @param modelService the modelService to set
     */
    public void setModelService(ModelService modelService) {
        this.modelService = modelService;
    }

    /**
     * @return the restTemplate
     */
    public RestTemplate getRestTemplate() {
        return restTemplate;
    }

    /**
     * @param restTemplate
     *            the restTemplate to set
     */
    public void setRestTemplate(final RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public SessionService getSessionService() {
        return sessionService;
    }

    public void setSessionService(SessionService sessionService) {
        this.sessionService = sessionService;
    }

    public UserService getUserService() {
        return userService;
    }

    public void setUserService(UserService userService) {
        this.userService = userService;
    }

    public TaskExecutor getTaskExecutor() {
        return taskExecutor;
    }

    public void setTaskExecutor(TaskExecutor taskExecutor) {
        this.taskExecutor = taskExecutor;
    }
}