package com.external.integration.tasks;

import com.external.integration.enums.AuditLoggingTypeEnum;
import com.external.integration.model.AuditLoggingModel;
import de.hybris.platform.core.model.user.UserModel;
import de.hybris.platform.servicelayer.model.ModelService;
import de.hybris.platform.servicelayer.session.Session;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/**
 * A task to send notification to customers
 */
public class AuditLoggingTask implements Runnable
{
	private static final Logger LOG = LoggerFactory.getLogger(AuditLoggingTask.class);

	private Session session;
	private String requestName;
	private String endPointUrl;
	private String request;
	private String response;
	private Integer attempt;
	private String responseCode;
	private UserModel userModel;
	private AuditLoggingTypeEnum type;
	private ModelService modelService;

	boolean responseAttributeSaveDisabled;

	public AuditLoggingTask(Session session, String requestName, String endPointUrl, String request, String response, Integer attempt, String responseCode, UserModel userModel, AuditLoggingTypeEnum type, ModelService modelService)
	{
		this.session = session;
		this.requestName = requestName;
		this.endPointUrl = endPointUrl;
		this.request = request;
		this.response = response;
		this.attempt = attempt;
		this.responseCode = responseCode;
		this.userModel = userModel;
		this.type = type;
		this.modelService = modelService;
	}

	@Override
	public void run()
	{
		final AuditLoggingModel auditLog = modelService.create(AuditLoggingModel.class);

		try{
			auditLog.setType(type);
			auditLog.setRequestName(requestName);
			auditLog.setEndPointUrl(endPointUrl);
			auditLog.setRequestLog(request);
			auditLog.setResponseLog(response);
			auditLog.setAttemptNumber(attempt);
			auditLog.setResponseCode(responseCode);

			if(null != userModel) {
				auditLog.setUserId(userModel.getUid());
				auditLog.setUserPk(userModel.getPk().toString());
			}
			if(null != session) {
				auditLog.setSessionId(session.getSessionId());
			}
			modelService.save(auditLog);
		}
		catch (Exception e){
			try {
				auditLog.setResponseLog(null);
				modelService.save(auditLog);
			}
			catch (Exception se) {
				LOG.error("Not able to save in webserviceAuditLog for " + type.getCode() + " and for the request name "
						+ requestName, e);
			}
		}
	}
}
