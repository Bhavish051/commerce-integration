/*
 * Copyright (c) 2021 SAP SE or an SAP affiliate company. All rights reserved.
 */
package com.external.integration.setup;

import static com.external.integration.constants.CommerceintegrationConstants.PLATFORM_LOGO_CODE;

import de.hybris.platform.core.initialization.SystemSetup;

import java.io.InputStream;

import com.external.integration.constants.CommerceintegrationConstants;
import com.external.integration.service.CommerceintegrationService;


@SystemSetup(extension = CommerceintegrationConstants.EXTENSIONNAME)
public class CommerceintegrationSystemSetup
{
	private final CommerceintegrationService commerceintegrationService;

	public CommerceintegrationSystemSetup(final CommerceintegrationService commerceintegrationService)
	{
		this.commerceintegrationService = commerceintegrationService;
	}

	@SystemSetup(process = SystemSetup.Process.INIT, type = SystemSetup.Type.ESSENTIAL)
	public void createEssentialData()
	{
		commerceintegrationService.createLogo(PLATFORM_LOGO_CODE);
	}

	private InputStream getImageStream()
	{
		return CommerceintegrationSystemSetup.class.getResourceAsStream("/commerceintegration/sap-hybris-platform.png");
	}
}
